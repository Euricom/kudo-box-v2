import Navbar from '../components/Navbar/Navbar'

export default function MyKudos() {
    return (
        <div>
            <Navbar />
            <h1>My Kudos</h1>
        </div>
    )
}
