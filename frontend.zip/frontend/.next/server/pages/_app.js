(function() {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 3374:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ _app; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: external "next/head"
var head_namespaceObject = require("next/head");;
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
;// CONCATENATED MODULE: external "@azure/msal-browser"
var msal_browser_namespaceObject = require("@azure/msal-browser");;
// EXTERNAL MODULE: external "@azure/msal-react"
var msal_react_ = __webpack_require__(6209);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: ./src/auth/CustomNavigationClient.ts
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


class CustomNavigationClient extends msal_browser_namespaceObject.NavigationClient {
  constructor(router) {
    super();

    _defineProperty(this, "router", void 0);

    this.router = router;
  } // TYPE OF OPTIONS???


  async navigateInternal(url, options) {
    const relativePath = url.replace(window.location.origin, '');
    if (options.noHistory) this.router.replace(relativePath);else this.router.push(relativePath);
    return false;
  }

}
;// CONCATENATED MODULE: ./src/components/AzureAD.tsx






const msalConfig = {
  auth: {
    clientId: "520f1246-722b-41f7-8159-e052d24378dd",
    authority: "https://login.microsoftonline.com/0b53d2c1-bc55-4ab3-a161-927d289257f2",
    postLogoutRedirectUri: '/'
  }
};
const loginRequest = {
  scopes: ['User.Read']
};

const AzureAD = ({
  children
}) => {
  const router = (0,router_.useRouter)();
  const msalInstanceRef = (0,external_react_.useRef)(new msal_browser_namespaceObject.PublicClientApplication(msalConfig));
  (0,external_react_.useEffect)(() => {
    setMsalRouter();
    setActiveMsalAccount();
  }, []);

  const setMsalRouter = () => {
    const navigationClient = new CustomNavigationClient(router);
    msalInstanceRef.current.setNavigationClient(navigationClient);
  };

  const setActiveMsalAccount = () => {
    const accounts = msalInstanceRef.current.getAllAccounts();

    if (accounts.length > 0) {
      msalInstanceRef.current.setActiveAccount(accounts[0]);
    }

    msalInstanceRef.current.addEventCallback(event => {
      if (event.payload && event.eventType === msal_browser_namespaceObject.EventType.LOGIN_SUCCESS && event.payload.account) {
        const account = event.payload.account;
        msalInstanceRef.current.setActiveAccount(account);
      }
    });
  };

  return /*#__PURE__*/jsx_runtime_.jsx(msal_react_.MsalProvider, {
    instance: msalInstanceRef.current,
    children: /*#__PURE__*/jsx_runtime_.jsx(msal_react_.MsalAuthenticationTemplate, {
      interactionType: msal_browser_namespaceObject.InteractionType.Redirect,
      authenticationRequest: loginRequest,
      children: children
    })
  });
};

/* harmony default export */ var components_AzureAD = (AzureAD);
;// CONCATENATED MODULE: ./src/pages/_app.tsx




function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _app_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _app_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





function MyApp({
  Component,
  pageProps
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("meta", {
        charSet: "utf-8"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        httpEquiv: "X-UA-Compatible",
        content: "IE=edge"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "viewport",
        content: "width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "description",
        content: "Description"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "keywords",
        content: "Keywords"
      }), /*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "Ekudo"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "manifest",
        href: "/manifest.json"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        href: "/euricom.png",
        rel: "icon",
        type: "image/png"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "theme-color",
        content: "#ffffff"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(components_AzureAD, {
      children: /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps))
    })]
  });
}

/* harmony default export */ var _app = (MyApp);

/***/ }),

/***/ 6209:
/***/ (function(module) {

"use strict";
module.exports = require("@azure/msal-react");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 5282:
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__(3374));
module.exports = __webpack_exports__;

})();